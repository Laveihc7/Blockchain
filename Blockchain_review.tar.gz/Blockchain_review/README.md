# Note Lambda

## Overview 